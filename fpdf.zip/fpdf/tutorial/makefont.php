<?php
// G�n�ration des fichiers de police pour le tutoriel 7
require('../makefont/makefont.php');

MakeFont('CevicheOne-Regular.ttf', 'cp1252');
?>
